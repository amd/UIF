#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2
from AMO_modules.helper_routines import query_fusion_pattern_nodes
from AMO_modules.helper_functions import modify_parent_child


def remove_bias_reshape_shape(node_name_details):
    # Re-searching this pattern without FNs
    target_pattern = query_fusion_pattern_nodes(node_name_details, [['Mul'],['Conv2D'],['BiasAdd'],['Squeeze'],['Reshape'],['Softmax'],['Reshape']])

    for current_pattern in target_pattern:
        # Accessing squeeze's input
        bias_add_node = node_name_details[current_pattern[3]].node.input[0]

        bias_FN = node_name_details[bias_add_node].node.input[1]
        q_pos_attr_value = node_name_details[bias_FN].node.attr['quantize_pos'].i
        node_name_details[current_pattern[1]].node.attr['bias_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

        # Linking weights i/p to conv to bypass 'biases/wquant' FN
        node_name_details[current_pattern[1]].node.input.append(node_name_details[bias_FN].node.input[0])

        # Appending the conv layer as input to squeeze
        node_name_details[current_pattern[3]].node.input.append(current_pattern[1])

        # Removing biasadd from spatial squeeze's input
        node_name_details[current_pattern[3]].node.input.pop(0)
        node_name_details.pop(bias_FN) #optional, if used, no wquant FNs of bias add will be present and no need to call remove all FNs
        node_name_details.pop(current_pattern[2])

        # Removing shape from node_name_details and also from reshape (removing from node_name_details to avoid dangling const nodes)
        node_name_details.pop(node_name_details[current_pattern[4]].node.input.pop(1))

        # Appending squeeze to softmax
        node_name_details[current_pattern[5]].node.input.append(current_pattern[3])

        # Removing reshape from node_name_details and also from the input of softmax
        node_name_details.pop(node_name_details[current_pattern[5]].node.input.pop(0))

        # Removing shape from node_name_details and also from reshape
        node_name_details.pop(node_name_details[current_pattern[6]].node.input.pop(1))
        # Removing reshape that is at the end of the network
        node_name_details.pop(current_pattern[6])

    target_pattern = query_fusion_pattern_nodes(node_name_details, [['Conv2D'],['BiasAdd'],['Squeeze']])

    for current_pattern in target_pattern:
        bias_add_node = node_name_details[current_pattern[2]].node.input[0]
        bias_FN = node_name_details[bias_add_node].node.input[1]
        q_pos_attr_value = node_name_details[bias_FN].node.attr['quantize_pos'].i
        node_name_details[current_pattern[0]].node.attr['bias_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))
        node_name_details[current_pattern[0]].node.input.append(node_name_details[bias_FN].node.input[0])

        node_name_details[current_pattern[2]].node.input.append(current_pattern[0])
        node_name_details[current_pattern[2]].node.input.pop(0)
        node_name_details.pop(bias_FN) #optional, if used, no wquant FNs of bias add will be present and no need to call remove all FNs
        node_name_details.pop(current_pattern[1])

    modify_parent_child(node_name_details)
    graph_details = copy.copy(node_name_details)

    target_pattern = query_fusion_pattern_nodes(node_name_details, [['Squeeze'],['Shape']])
    for current_pattern in target_pattern:
        node_name_details.pop(current_pattern[1])

    modify_parent_child(node_name_details)
    graph_details = copy.copy(node_name_details)

    return(node_name_details)