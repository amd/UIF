#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2, types_pb2
from AMO_modules.helper_routines import query_fusion_pattern_nodes


def rename_add_with_skip_input(node_name_details):
    ''' The below block is meant to change ADD nodes to ADDV2 so as to identify those ADDs that have 2
    inputs(both as FN, meaning the skip connection). If here it is not renamed, there will be no
    difference between these add nodes and the add node for bias, thus we might endup disturbing
    these nodes while removing bias adds '''

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        if node_name_details[current_node].node.op == 'Add' or node_name_details[current_node].node.op == 'AddV2':
            parents = node_name_details[current_node].parent
            if(node_name_details[parents[0]].node.op == 'FixNeuron' and node_name_details[parents[1]].node.op == 'FixNeuron'):
                # To confirm whether the FNs are aquant nodes
                if(node_name_details[node_name_details[parents[0]].node.input[0]].node.op != 'Const' and \
                node_name_details[node_name_details[parents[1]].node.input[0]].node.op != 'Const'):
                    if(node_name_details[parents[0]].node.attr["_output_shapes"] == node_name_details[parents[0]].node.attr["_output_shapes"]):
                        node_name_details[current_node].node.op = 'MergeAdd'

    return node_name_details

# We intend to filter target_pattern and from there, the bias node(at the end of the network) as we only remove the remaining bias add nodes other than addv2 and those at the end
# We leave the bias add at the end of the network as we would search for patterns including that bias node at the tail transformation

def query_logit_bias_nodes(node_name_details):
    target_pattern = query_fusion_pattern_nodes(node_name_details, [['Mul'],['FixNeuron'],['Conv2D'],['BiasAdd'],['FixNeuron'],['Squeeze'],['FixNeuron'],['Reshape'],['FixNeuron'],['Softmax'],['Reshape']])
    bias_add_node = target_pattern[0][3] if target_pattern else 'NA'

    target_pattern_VGG = query_fusion_pattern_nodes(node_name_details, [['Conv2D'],['BiasAdd'],['FixNeuron'],['Squeeze']])
    bias_add_node_VGG = target_pattern_VGG[0][1] if target_pattern_VGG else 'NA'

    return bias_add_node, bias_add_node_VGG

# To check the mul nodes to be retained (scale value > threshold) and those to be removed
def check_mul_nodes(node_name_details):

    graph_details = copy.copy(node_name_details)

    mul_nodes_to_be_retained = []
    mul_nodes_to_be_eliminated = []

    for current_node in graph_details:
        if node_name_details[current_node].node.op =='Mul' :
            mul_node_input = None
            # Accessing the input scale value to the mul node
            for i in range(len(node_name_details[current_node].node.input)):
                if(node_name_details[node_name_details[current_node].node.input[i]].node.op == 'Const'):
                    mul_node_input = node_name_details[current_node].node.input[i]

            # Enters the block only if mul node has a const value as input
            if(mul_node_input != None):
                bytes_val = node_name_details[mul_node_input].node.attr["value"].tensor.tensor_content
                # Checking for the dtype of the value and decoding it accordingly
                dtype_val = node_name_details[mul_node_input].node.attr["value"].tensor.dtype
                val = tf.io.decode_raw(bytes_val, dtype_val)

                # Check if the constant scale is a single value
                if(val.shape == (1,)):
                    # Retain mul nodes whose scales are not close to unity and would cause significant change
                    if(val < 0.98 and val > 1.01):
                        mul_nodes_to_be_retained.append(current_node)
                    else:
                        mul_nodes_to_be_eliminated.append(current_node)

    return(mul_nodes_to_be_retained, mul_nodes_to_be_eliminated)

def assign_intermed_float_scale(node_name_details, mul_nodes_to_be_retained):
    target_pattern = query_fusion_pattern_nodes(node_name_details, [['FixNeuron'],['AvgPool'],['Mul'],['FixNeuron'],['Conv2D']])

    for current_pattern in target_pattern:
        q_pos_attr_value_1 = node_name_details[current_pattern[0]].node.attr['quantize_pos']
        q_pos_attr_value_2 = node_name_details[current_pattern[3]].node.attr['quantize_pos']
        q_intermediate = q_pos_attr_value_2.i - q_pos_attr_value_1.i

        if(current_pattern[2] in mul_nodes_to_be_retained):
            ''' If the mul node is to be retained, we add the 'intermed_float_scale' to adjust the scale
            post the float operation in mul and pass the 'in_scale' as q_pos of FN between mul and conv'''
            node_name_details[current_pattern[4]].node.attr['intermediate_float_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_intermediate))
            node_name_details[current_pattern[4]].node.attr['in_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value_2.i))
        else:
            ''' If the mul node is not retained, 'in_scale' is passed from q_pos of FN preceeding average pool
            which is the 'out_scale' of preceeding conv layer '''
            node_name_details[current_pattern[4]].node.attr['in_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value_1.i))

    return node_name_details