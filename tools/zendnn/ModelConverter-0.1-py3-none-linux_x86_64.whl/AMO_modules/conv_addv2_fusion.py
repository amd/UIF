#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
from collections import namedtuple
import copy
from tensorflow.core.framework import attr_value_pb2
from AMO_modules.helper_functions import modify_parent_child, find_parent_shortcut


# AddV2 is removed
def fuse_addv2_with_conv(node_name_details):

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        if 'Conv' in current_node:
            node_name_details[current_node].node.attr['is_sum'].CopyFrom(attr_value_pb2.AttrValue(b=False))

    for current_node in graph_details:
        if node_name_details[current_node].node.op == 'MergeAdd':
            children = node_name_details[current_node].children

            conv_node, node_to_be_merged = find_parent_shortcut(current_node, node_name_details)

            node_name_details[conv_node].node.attr['is_sum'].CopyFrom(attr_value_pb2.AttrValue(b=1))

            # Add 'add_out_scale'
            q_pos_attr_value = node_name_details[current_node].node.attr['add_out_scale'].i
            node_name_details[conv_node].node.attr['add_out_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

            node_name_details[conv_node].node.input.append(node_to_be_merged)
            for child in children :
                length = len(node_name_details[child].node.input)
                for idx in range(0, length):
                    if node_name_details[child].node.input[idx] == current_node :
                        node_name_details[child].node.input[idx] = conv_node

            node_name_details.pop(current_node)
            ''' calling modify_parent_child() so that, after each iteration, parent list of the
            nodes get updated along with the input list. This will eliminate key error in case
            (like in efficient net) one MergeAdd node is given as input to another MergeAdd node '''
            modify_parent_child(node_name_details)

    return(node_name_details)