#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2


def fuse_weights_with_conv(node_name_details):

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        # Logic to deal with Weights
        if current_node in node_name_details.keys():
            if node_name_details[current_node].node.op =='Conv2D' or node_name_details[current_node].node.op =='DepthwiseConv2dNative':
                inputs = node_name_details[current_node].node.input
                weights_FN = inputs[1]
                node_name_details[current_node].node.input.append(node_name_details[weights_FN].node.input[0])
                q_pos_attr_value = node_name_details[weights_FN].node.attr['quantize_pos']
                # Typecasting as int
                q_pos_attr_value = q_pos_attr_value.i

                node_name_details.pop(weights_FN)
                node_name_details[current_node].node.attr['weight_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))
                node_name_details[current_node].node.input.pop(1)

    return(node_name_details)


def fuse_biases_with_conv(node_name_details, bias_add_node, bias_add_node_VGG):

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        # Logic to deal with Weights
        # Look for BiasAdd also here itself and adjust processing at later stages
        if current_node in node_name_details.keys():
            if node_name_details[current_node].node.op =='Add' or node_name_details[current_node].node.op =='BiasAdd' or node_name_details[current_node].node.op =='AddV2':
                if current_node != bias_add_node \
                    and current_node != bias_add_node_VGG \
                    and current_node != 'InceptionV4/Logits/Logits/BiasAdd' \
                    and current_node != 'efficientnet-edgetpu-S/model/head/dense/BiasAdd'\
                    and current_node != 'efficientnet-edgetpu-M/model/head/dense/BiasAdd' \
                    and current_node != 'efficientnet-edgetpu-L/model/head/dense/BiasAdd' \
                    and current_node != 'refinedet320/fc6_m/BiasAdd':

                    inputs = node_name_details[current_node].node.input

                    # FN(biases/wquant) is always inputs[1] for the add node (TODO: generalise the code later when needed)
                    bias_FN = inputs[1]
                    q_pos_attr_value = node_name_details[bias_FN].node.attr['quantize_pos']

                    #parent[0] is always non-FN input for Add node (TODO: generalise the code later when needed)
                    parent = node_name_details[current_node].parent[0]

                    children = node_name_details[current_node].children

                    # Add biases input to parent conv node
                    node_name_details[parent].node.input.append(node_name_details[bias_FN].node.input[0])
                    node_name_details.pop(bias_FN)

                    # Linking all children to conv node as biasadd will be removed
                    for child in children:
                        length = len(node_name_details[child].node.input)
                        for idx in range(0, length):
                            if node_name_details[child].node.input[idx] == current_node :
                                node_name_details[child].node.input[idx] = parent
                    node_name_details.pop(current_node)

                    q_pos_attr_value = q_pos_attr_value.i
                    node_name_details[parent].node.attr['bias_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

    return(node_name_details)

def fuse_relu_with_conv(node_name_details, initialize):
    # Remove RELU nodes that come after Conv2D nodes
    graph_details = copy.copy(node_name_details)

    # Only the first time relu is removed, the 'is_relu' attribute is initialised
    if(initialize == 1):
        for current_node in graph_details:
            if 'Conv' in current_node:
                node_name_details[current_node].node.attr['is_relu'].CopyFrom(attr_value_pb2.AttrValue(b=False))

    for current_node in graph_details:
        if node_name_details[current_node].node.op == 'Relu' or node_name_details[current_node].node.op == 'Relu6':
            parents = node_name_details[current_node].parent
            children = node_name_details[current_node].children
            if 'Conv' in parents[0] or 'depthwise' in parents[0] and len(parents) == 1:
                node_name_details[parents[0]].node.attr['is_relu'].CopyFrom(attr_value_pb2.AttrValue(b=True))
                if(node_name_details[current_node].node.op == 'Relu6'):
                    node_name_details[parents[0]].node.attr['relu_alpha'].CopyFrom(attr_value_pb2.AttrValue(f=6.0))
                for child in children:
                    length = len(node_name_details[child].node.input)
                    for idx in range(0, length):
                        if node_name_details[child].node.input[idx] == current_node :
                            node_name_details[child].node.input[idx] = parents[0]
                node_name_details.pop(current_node)

    return(node_name_details)

# Remove all existing relus (if any)
def remove_remaining_relus(node_name_details):

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        if node_name_details[current_node].node.op =='Relu':
            if current_node == 'refinedet320/fc6_m/Relu':
                continue
            parent = node_name_details[current_node].parent[0]
            children = node_name_details[current_node].children

            print(f'Parents: {parent}\nCurrent Node:{current_node}\nChildren:{children}\n')

            for child in children:
                length = len(node_name_details[child].node.input)
                for idx in range(0, length):
                    if node_name_details[child].node.input[idx] == current_node :
                        node_name_details[child].node.input[idx] = parent

            node_name_details.pop(current_node)

    return(node_name_details)