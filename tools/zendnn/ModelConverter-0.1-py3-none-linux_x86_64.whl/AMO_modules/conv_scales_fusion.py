#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2
from AMO_modules.helper_functions import function_find_child_FN


def fuse_scales_with_conv(node_name_details):

    graph_details = copy.copy(node_name_details)

    ''' Remove FN nodes that come before and after Conv nodes and update in_scale, out_scale
    -> Conv nodes with Conv nodes in the child path will have out_scale = 1
    -> out_scale = -1 after Mul node
    -> in_scale is always added to Conv node based on the parental FixNeuron '''

    # in_scale
    for current_node in graph_details:
        # Logic to deal with FNs that are inputs to Conv2D
        # Make this logic simpler by looking for Conv2D nodes and just updating with quant_pos of parent FN
        if node_name_details[current_node].node.op == "FixNeuron":
            children = node_name_details[current_node].children
            parent = node_name_details[current_node].parent
            q_pos_attr_value = node_name_details[current_node].node.attr['quantize_pos'].i

            for child in children:
                if node_name_details[child].node.op == "Conv2D" or node_name_details[child].node.op == "DepthwiseConv2dNative":
                    # Checking if the FN's parent is a mul node
                    if(node_name_details[parent[0]].node.op == 'Mul'):
                        # This is handled in the intermed_float_scale_for_inception()
                        continue
                    else:
                        node_name_details[child].node.attr['in_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

    # out_scale (recrusive function call, should lead to number, 1, or -1?)
    for current_node in graph_details:
        if node_name_details[current_node].node.op == "Conv2D" or node_name_details[current_node].node.op == "DepthwiseConv2dNative":
            q_pos_attr_value = function_find_child_FN(current_node, node_name_details)
            node_name_details[current_node].node.attr['out_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

    # get add_out_scale to ADDV2
    for current_node in graph_details:
        if node_name_details[current_node].node.op == 'MergeAdd':
            q_pos_attr_value = function_find_child_FN(current_node, node_name_details)
            node_name_details[current_node].node.attr['add_out_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value))

    return(node_name_details)