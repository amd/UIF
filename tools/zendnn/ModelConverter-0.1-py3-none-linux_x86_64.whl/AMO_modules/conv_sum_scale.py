#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
from collections import namedtuple
import copy
from tensorflow.core.framework import attr_value_pb2


def get_sum_scale(node_name_details):

    graph_info = copy.copy(node_name_details)

    # Add sum_scale
    for current_node in graph_info:
        if node_name_details[current_node].node.op == 'Conv2D':
            # .b returns "True"/"False"
            q_pos_attr_value = node_name_details[current_node].node.attr['is_sum'].b
            if q_pos_attr_value:
                # Accessing the skip connection input
                shortcut_input = node_name_details[current_node].node.input[3]
                if node_name_details[shortcut_input].node.op == 'Conv2D' :
                    if node_name_details[shortcut_input].node.attr['is_sum'].b:
                        q_pos_attr_value_1 = node_name_details[shortcut_input].node.attr['add_out_scale'].i
                    else:
                        q_pos_attr_value_1 = node_name_details[shortcut_input].node.attr['out_scale'].i
                else :
                    # If the shortcut input is not Conv2D, track the shortcut input's parent conv node
                    parent_new = node_name_details[shortcut_input].parent
                    if node_name_details[parent_new[0]].node.attr['is_sum'].b:
                        q_pos_attr_value_1 = node_name_details[parent_new[0]].node.attr['add_out_scale'].i
                    else:
                        q_pos_attr_value_1 = node_name_details[parent_new[0]].node.attr['out_scale'].i
                node_name_details[current_node].node.attr['sum_scale'].CopyFrom(attr_value_pb2.AttrValue(i=q_pos_attr_value_1))

    return(node_name_details)