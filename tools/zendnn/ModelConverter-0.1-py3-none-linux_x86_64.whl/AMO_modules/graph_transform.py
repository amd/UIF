#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import argparse
import copy
import tensorflow as tf
from tensorflow.core.framework import attr_value_pb2, types_pb2
from AMO_modules.helper_routines import query_fusion_pattern_nodes
from AMO_modules.helper_functions import print_number_of_FNs,  modify_parent_child
from AMO_modules.preprocessing import get_output_path, get_graph_details
from AMO_modules.bootstrap import rename_add_with_skip_input, query_logit_bias_nodes, check_mul_nodes, assign_intermed_float_scale
from AMO_modules.conv_param_fusion import fuse_weights_with_conv, fuse_biases_with_conv, fuse_relu_with_conv, remove_remaining_relus
from AMO_modules.conv_scales_fusion import fuse_scales_with_conv
from AMO_modules.remove_fix_neurons import remove_FNs_with_aquant
from AMO_modules.conv_addv2_fusion import fuse_addv2_with_conv
from AMO_modules.conv_sum_scale import get_sum_scale
from AMO_modules.bias_shape_transform import remove_bias_reshape_shape
from AMO_modules.rename_and_assign_dtypes import rename_assign_dtypes, matmul_biasadd_fixes
from AMO_modules.graph_validation import is_graph_valid


node_name_details = {}

def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_file", type=str, required=True,
                        help="Pretrained TF frozen '.pb' model file.")
    parser.add_argument("--out_location", type=str, default='.',
                         help='Location to write AMD optimized file. '
                              'Default is current directory.')
    args = parser.parse_args()
    return args

def main():
    # Preprocessing
    args = get_arguments()
    amd_opt_pb = get_output_path(args.model_file, args.out_location)

    node_name_details = get_graph_details(args.model_file)

    print_number_of_FNs(node_name_details)

    # Bootstrapping
    try:
        node_name_details = rename_add_with_skip_input(node_name_details)
        bias_add_node, bias_add_node_VGG = query_logit_bias_nodes(node_name_details)
    except:
        print("\nThis model is not supported for preprocessing of add nodes")
        exit(0)

    try:
        # To remove mul nodes wherever insignificant, depending on threshold
        mul_nodes_to_be_retained, mul_nodes_to_be_eliminated = check_mul_nodes(node_name_details)
        node_name_details = assign_intermed_float_scale(node_name_details, mul_nodes_to_be_retained)

        modify_parent_child(node_name_details)
    except:
        print("\nThis model is not supported for handling mul nodes")
        exit(0)

    # Convolution's parameters fusion

    # Weights and biases
    try:
        node_name_details = fuse_weights_with_conv(node_name_details)
        node_name_details = fuse_biases_with_conv(node_name_details, bias_add_node, bias_add_node_VGG)

        modify_parent_child(node_name_details)
        print_number_of_FNs(node_name_details)
    except:
        print("\nThis model is not supported for convolution parameters fusion")
        exit(0)

    # Removing relu. Sending parameter 1, so as to indicate that the 'is_relu' should be intialised to false
    try:
        node_name_details = fuse_relu_with_conv(node_name_details, 1)

        modify_parent_child(node_name_details)
    except:
        print("\nThis model is not supported for Relu fusion")
        exit(0)

    # Fusing scales->extracting in_scale, out_scale and add_out scale
    try:
        node_name_details = fuse_scales_with_conv(node_name_details)
    except:
        print("\nThis model is not supported for convolution scales fusion")
        exit(0)

    # Removing FNs ending aquant
    try:
        node_name_details = remove_FNs_with_aquant(node_name_details)

        modify_parent_child(node_name_details)
        print_number_of_FNs(node_name_details)
    except:
        print("\nThis model is not supported for handling FixNeurons")
        exit(0)

    # Convolution and addv2 fusion
    try:
        node_name_details = fuse_addv2_with_conv(node_name_details)

        modify_parent_child(node_name_details)
    except:
        print("\nThis model is not supported for MergeAdd nodes fusion")
        exit(0)

    ''' Again we do this step because previously we would have removed only relus following conv nodes
    and left those following addv2. Now after rearranging the nodes and removing ADDV2, relus come after
    conv. Remove these RELU nodes that come after CONV2D nodes with 'is_sum' enabled '''
    try:
        node_name_details = fuse_relu_with_conv(node_name_details, 0)

        modify_parent_child(node_name_details)

        # Removing remaining relus if any
        node_name_details = remove_remaining_relus(node_name_details)

        modify_parent_child(node_name_details)
    except:
        print("\nThis model is not supported for Relu fusion")
        exit(0)

    # Adding sum scale
    try:
        node_name_details = get_sum_scale(node_name_details)

        modify_parent_child(node_name_details)
    except:
        print("\nThis model is not supported for handling sum scale")
        exit(0)

    # Re-searching patterns to remove biasadd node at the end of the network, reshape, shape nodes
    try:
        node_name_details = remove_bias_reshape_shape(node_name_details)

        modify_parent_child(node_name_details)
        print_number_of_FNs(node_name_details)
    except:
        print("\nThis model is not supported for handling bias reshape")
        exit(0)

    # Adding atributes Tinput, Toutput, Tsum, changing mean to avgpool, removing mul
    try:
        node_name_details = rename_assign_dtypes(node_name_details, mul_nodes_to_be_retained, mul_nodes_to_be_eliminated)
    except:
        print("\nThis model is not supported for handling and assigning data type attribute")
        exit(0)

    # Creating output graph
    output_graph_def = tf.compat.v1.GraphDef()
    output_graph_def_copy = tf.compat.v1.GraphDef()
    for _, v in node_name_details.items():
        output_graph_def.node.extend([v.node])

    # Model specific temperory fixes for matmul layers and biasadd logits layer
    try:
        output_graph_def = matmul_biasadd_fixes(output_graph_def)

        print_number_of_FNs(node_name_details)
    except:
        print("\nThis model is not supported for matmul-biasadd handling")
        exit(0)

    # To remove fixed batch size of all nodes, if any, by assigning -1
    for node in output_graph_def.node:
        try:
            # Checking with the op type 'Placeholder' to find the input layer
            if(node.op == 'Placeholder'):
                node.attr['shape'].shape.dim[0].size = -1

            # Checking if '_output_shapes' attribute is present and dimension is not empty
            if(node.attr.get('_output_shapes') is not None and
            len(node.attr['_output_shapes'].list.shape[0].dim) != 0):
                node.attr['_output_shapes'].list.shape[0].dim[0].size = -1
        except:
            pass

    try:
        ''' Take a copy of the graph to pass for validation so that the original graph does not
        get affected by addition of any extra attributes '''
        output_graph_def_copy = copy.deepcopy(output_graph_def)
        is_graph_valid(output_graph_def_copy)
    except:
        print("\nThis model is not supported for optimization")
        exit(0)

    print("\nGraph validation is successful")

    # Writing the output to output file only if the optimization of the model is correct
    with tf.compat.v2.io.gfile.GFile(amd_opt_pb, "wb") as f:
            f.write(output_graph_def.SerializeToString())

    print("Model has been properly optimized and saved")

if __name__ == "__main__":
    main()