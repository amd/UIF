#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf


def is_graph_valid(output_graph_def):
    node_list = []
    input_list = []
    input_shape = [1]

    for current_node in output_graph_def.node:
        # Checking with the op type 'Placeholder' to find the input layer
        if(current_node.op == 'Placeholder'):
            input_layer = current_node.name
            # Getting the input dimensions according to the input layer's requirement
            for dim_index in range(1,4):
                input_shape.append(current_node.attr['shape'].shape.dim[dim_index].size)

        node_list.append(current_node.name)
        input_list.extend(current_node.input)

    ''' We save all nodes in 'node_list' and inputs of all nodes in 'input_list'.
    If a model is an output node, it is not fed as input to any other node, so it will not
    be present in input list. 'outputs' will finally have only those output nodes that are
    present in 'node_list' but not in 'input_list' '''
    outputs = set(node_list) - set(input_list)

    # Synthetic image data generation of the dimension 'input_shape'
    data_graph = tf.Graph()
    with data_graph.as_default():
        images = tf.random.truncated_normal(
        input_shape,
        dtype=tf.float32,
        stddev=10,
        name='synthetic_images')

    config = tf.compat.v1.ConfigProto()

    image_data = None

    with tf.compat.v1.Session(graph=data_graph, config=config) as sess:
        image_data = sess.run(images)

    # Changing 'graph_def' to 'graph' format
    graph = tf.Graph()
    with graph.as_default():
        tf.import_graph_def(output_graph_def, name='')

    input_tensor = graph.get_tensor_by_name(input_layer + ":0")
    # If there are more than one output layer, each output layer will have a separate output tensor
    output_tensor = [graph.get_tensor_by_name(output_layer + ":0") for output_layer in outputs]

    # Running the input through the optimized model
    with tf.compat.v1.Session(graph=graph, config=config) as sess:
        output = sess.run(output_tensor, {input_tensor: image_data})