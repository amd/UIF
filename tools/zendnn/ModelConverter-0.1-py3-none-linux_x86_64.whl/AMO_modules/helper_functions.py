#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import re
import copy
from tensorflow.core.framework import node_def_pb2
from tensorflow.core.framework import attr_value_pb2, types_pb2
from collections import namedtuple
from tensorflow.python.framework import tensor_util


def get_number_of_neurons(graph_def):
    values = []
    for value in graph_def.keys():
        if value.endswith('aquant') or value.endswith('wquant'):
            values.append(value)
    return len(values)

def print_number_of_FNs(graph_def):
        print('Number of FixNeurons left :', get_number_of_neurons(graph_def))
        print('\n')

def modify_parent_child(node_name_details):
        for node_name, node_details in node_name_details.items():
            for each_input in node_details.node.input:
                if each_input in node_name_details:
                    node_name_details[node_name].parent.clear()
                    node_name_details[node_name].children.clear()
                else :
                    continue

        # Update parent and child lists. Very important
        for node_name, node_details in node_name_details.items():
            for each_input in node_details.node.input:
                if each_input in node_name_details :
                    if node_name_details[each_input].node.op != "Const" :
                        node_name_details[node_name].parent.append(each_input)
                        node_name_details[each_input].children.append(node_name)
                else :
                    continue

def function_find_child_FN(current_node, node_name_details):
    # To find the first child fix neuron from 'current_node'
    for each_child in node_name_details[current_node].children:

        if each_child.endswith('aquant'):
            q_pos_attr_value = node_name_details[each_child].node.attr['quantize_pos']
            q_pos_attr_value = q_pos_attr_value.i
            return q_pos_attr_value
        else:
            return function_find_child_FN(each_child, node_name_details)
    # Returning 1 as there should be no scaling done if there is no FN following a node
    return 1

def isrelu_of_first_preceding_conv(current_node, node_name_details):
    if node_name_details[current_node].node.op =='Conv2D' or  node_name_details[current_node].node.op == 'DepthwiseConv2dNative':
        return  node_name_details[current_node].node.attr['is_relu'].b
    else:
        # Currently, single parent branch exists for all these nodes (TODO : Can generalise to multiple parental chains if needed)

        # This condition mostly falls when parent is maxpool or avgpool
        if(len(node_name_details[current_node].parent) > 0):
            parent_node = node_name_details[current_node].parent[0]

            # Checking the conv layer bfr that maxpool/avgpool's for 'isrelu'
            return isrelu_of_first_preceding_conv(parent_node, node_name_details)
        else:
            ''' Recursive call leads to a call from the first conv node in the graph that inturn
            ends up in calling the function from 'input' node, that has no parent nodes '''
            print("Note : Convolution node with no conv node in parental chain detected")
            # Returning -1 because the conv node passed has to have float as input type as there is no preceeding conv node
            return -1

def find_first_conv_node_in_parental_chain(current_node, node_name_details):
    if 'Conv' in each_node:
        return current_node
    else:
        if(len(node_name_details[current_node].parent) > 0):
            parent_node = node_name_details[current_node].parent[0]
            return find_first_conv_node_in_parental_chain(parent_node, node_name_details)
        else:
            print("Error Note : Squeeze node or Given node with no conv node in parental chain detected")

def set_tout_to_first_parental_avgpool(each_input, node_name_details) :
    for current_node in node_name_details[each_input].parent:
        if node_name_details[current_node].node.op =='VitisAIAvgPool':
            node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            return
        else:
            set_tout_to_first_parental_avgpool(node_name_details[each_input].parent[0], node_name_details)

def find_first_non_fc_node_in_parental_chain(each_input, node_name_details):
    for current_node in node_name_details[each_input].parent:
        if 'fc' not in current_node:
            return current_node
        else:
            find_first_non_fc_node_in_parental_chain(current_node, node_name_details)

def set_t_to_all_children_nodes(current_node, node_name_details) :
    # Sets all Tin and Tout of the nodes following the curent node as float
    children = node_name_details[current_node].children
    for current_child in node_name_details[current_node].children:
        # Tinput, Toutput assignment for Conv node
        if 'Conv' in current_child :
            node_name_details[current_child].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            node_name_details[current_child].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
        # T for rest of the nodes
        else:
            node_name_details[current_child].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))

        set_t_to_all_children_nodes(current_child, node_name_details)

def find_parent_shortcut(mergeadd_node, node_name_details):
    parent_of_mergeadd = node_name_details[mergeadd_node].parent
    nodes_along_p0 = 0
    nodes_along_p1 = 0
    # The following loop executes twice as we go along two parents of the MergeAdd node
    for parent_path in range(len(parent_of_mergeadd)):
        # Depending on the parent path chosen, we trace back along that parent
        p = parent_of_mergeadd[parent_path]
        while(len(node_name_details[p].children) == 1):
            parent = node_name_details[p].parent
            for current_parent in parent:
                ''' Added a check for wquant, as mul node might contain wquant node as input (like in resnetv2)
                and might hang, as the parent node to mul might be mis-assigned as the wquant node if
                only the first condition is checked '''
                if(node_name_details[current_parent].node.op != "Const" and not current_parent.endswith("wquant")):
                    p = current_parent
            # Whenever we traverse through a node, increment the node count along the path
            if(parent_path == 0):
                nodes_along_p0 = nodes_along_p0 + 1
            else:
                nodes_along_p1 = nodes_along_p1 + 1

    ''' When tracing back from 'MergeAdd' node through parent_of_add[0], if number of nodes between
    merge add and first branching ancestor is greater than the nodes along the path through
    parent_of_add[1], parent_of_add[0] is conv node and parent_of_add[1] is shortcut '''
    if(nodes_along_p0 > nodes_along_p1):
        conv_node = parent_of_mergeadd[0]
        node_to_be_merged = parent_of_mergeadd[1]
    else:
        conv_node = parent_of_mergeadd[1]
        node_to_be_merged = parent_of_mergeadd[0]

    return(conv_node, node_to_be_merged)