#*******************************************************************************
#* Modifications Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#* Notified per clause 4(b) of the license.
#*******************************************************************************/

#/*******************************************************************************
#
#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2021 Intel Corporation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
#*******************************************************************************/

import re
import copy
from tensorflow.core.framework import node_def_pb2
from tensorflow.core.framework import attr_value_pb2
from collections import namedtuple
from tensorflow.python.framework import tensor_util


# Helper Utilities
# Store the output, siblings, parent, etc...
# implement the following algorithms
# 1. BFS
# 2. Connected Components
# 3. Lowest Common Ancestor
# 4. Topological sorting
# 5. Graph Partitioning
# 6. Connectivity
# 7. Negative Cycles
# 8. Bridges
# 9. Shortest Path Problem

def least_common_ancestor():
    return None

def topological_sorting():
    return None

def graph_partition():
    return None

def negative_cycles():
    return None

def connectivity():
    return None

def bfs(node_name_details, s):

    # Mark all the vertices as not visited
    visited = [False] * (max(len(list(node_name_details))) + 1)

    # Create a queue for BFS
    queue = []

    # Mark the source node as
    # visited and enqueue it
    queue.append(s)
    visited[s] = True

    while queue:

        # Dequeue a vertex from
        # queue and print it
        s = queue.pop(0)
        print (s, end = " ")

        # Get all adjacent vertices of the
        # dequeued vertex s. If a adjacent
        # has not been visited, then mark it
        # visited and enqueue it
        for i in node_name_details[s]:
            if visited[i] == False:
                queue.append(i)
                visited[i] = True


def _search_patterns(node_name_details, input_pattern):
    def _validate_input(data, creteria):
        if isinstance(creteria, str) and data == creteria:
            return True
        if isinstance(creteria, (list, tuple)) and data in creteria:
            return True

        return False

    def _compare_list(list_a, list_b):
        is_subset = True

        for index, value in enumerate(list_a):
            is_subset &= value == list_b[index]

        return is_subset

    def _dfs(op_names, op_types, graph_info, node, pattern):
        if pattern == []:
            return
        start_index = 0
        end_index = len(pattern) - 1
        matched_flag = False
        while start_index <= end_index:
            matched_flag = _validate_input(node.op, pattern[end_index])
            if not matched_flag and isinstance(pattern[end_index], tuple):
                end_index -= 1
                continue

            if matched_flag:
                op_names.append(node.name)
                op_types.append(node.op)
                break

            return

        if start_index == end_index:
            if matched_flag:
                matched_res = copy.deepcopy(op_names)
                matched_res.reverse()
                op_types_copy = copy.deepcopy(op_types)
                op_types_copy.reverse()
                matched_res.append(op_types_copy)
                if matched_res not in output_result:
                    output_result.append(matched_res)
                op_names.pop()
                op_types.pop()
            return

        for index, value in enumerate(node.input):
            cur_node = graph_info[value].node
            _dfs(op_names, op_types, graph_info, cur_node, pattern[:end_index])
            if index == len(node.input) - 1:
                op_names.pop()
                op_types.pop()

    output_result = []

    for _, v in node_name_details.items():
        start_index = len(input_pattern) - 1
        while start_index >= 0:
            find_first_match = _validate_input(v.node.op, input_pattern[start_index])
            if find_first_match:
                break
            if isinstance(input_pattern[start_index], tuple):
                start_index -= 1
                continue
            start_index = -2

        if start_index < 0:
            continue

        visited_op_name = []
        visited_op_types = []

        _dfs(visited_op_name, visited_op_types, node_name_details, v.node, input_pattern)

    sorted_output = sorted(output_result, key=lambda i: i[-1])
    useless_match_list = []

    for index, value in enumerate(sorted_output):
        if index == len(sorted_output) - 1:
            break
        next_matched_op_names = sorted_output[index + 1][:-1]
        if len(value[:-1]) < len(next_matched_op_names) and \
                _compare_list(value[:-1], next_matched_op_names):
            useless_match_list.append(value)

    for i in useless_match_list:
        sorted_output.remove(i)

    longest_match = {}
    final_output = []
    for i in sorted_output:
        key = i[0]
        if key not in longest_match:
            longest_match[key] = i[-1]
            continue

        if len(longest_match[key]) < len(i[-1]):
            longest_match[key] = i[-1]

    for i in sorted_output:
        if i[0] in longest_match and i[-1] == longest_match[i[0]]:
            final_output.append(i)

    return final_output

def query_fusion_pattern_nodes(node_name_details, patterns=None):
    return _search_patterns(node_name_details, patterns)


class GraphRewriterHelper():
    node_name_cache = {}
    node_name_port_cache = {}

    @staticmethod
    def compare_node_attr(node_a, node_b):
        if len(node_a.input) > 1:
            return False

        if node_a.input != node_b.input:
            return False

        if node_a.op != node_b.op:
            return False

        if len(node_a.attr) != len(node_b.attr):
            return False

        node_a_attr = sorted(list(node_a.attr))
        node_b_attr = sorted(list(node_b.attr))

        if node_a_attr != node_b_attr:
            return False

        for attr_name in node_a_attr:
            if node_a.attr[attr_name] != node_b.attr[attr_name]:
                return False

        return True

    @staticmethod
    def create_node(op, name, inputs):
        new_node = node_def_pb2.NodeDef()
        new_node.op = op
        new_node.name = name
        for input_name in inputs:
            new_node.input.extend([input_name])
        return new_node

    @staticmethod
    def create_constant_node(name, value, dtype, shape=None, device='cpu'):
        node = GraphRewriterHelper.create_node("Const" if device == 'cpu' else "HostConst", name,
                                               [])
        GraphRewriterHelper.set_attr_dtype(node, "dtype", dtype)
        GraphRewriterHelper.set_attr_tensor(node, "value", value, dtype, shape)
        return node

    @staticmethod
    def set_attr_dtype(node, key, value):
        """Set the attribute data type
        """
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(type=value.as_datatype_enum))

    @staticmethod
    def set_attr_tensor(node, key, value, dtype, shape=None):
        node.attr[key].CopyFrom(
            attr_value_pb2.AttrValue(
                tensor=tensor_util.make_tensor_proto(value, dtype=dtype, shape=shape)))

    @staticmethod
    def set_attr_string(node, key, value):
        """Set the node's attr which data type is string.
        """
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(s=value))

    @staticmethod
    def set_attr_int_list(node, key, value):
        """Set the node's attr which data type is int list.
        """
        list_value = attr_value_pb2.AttrValue.ListValue(i=value)
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(list=list_value))

    @staticmethod
    def set_attr_int(node, key, value):
        """Set the node's attr which data type is int.
        """
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(i=value))

    @staticmethod
    def set_attr_float(node, key, value):
        """Set the node's attr which data type is float.
        """
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(f=value))

    @staticmethod
    def set_attr_bool(node, key, value):
        """Set the node's attr which data type is bool.
        """
        node.attr[key].CopyFrom(attr_value_pb2.AttrValue(b=value))

    @staticmethod
    def node_name_from_input(node_name):
        """Static method that get the valid node name from input name.
        Args:
            node_name (string): node name defined in the input field.
        Returns:
            string: node's name
        """
        if node_name not in GraphRewriterHelper.node_name_cache:
            key = node_name
            if node_name.startswith("^"):
                node_name = node_name[1:]
            m = re.search(r"(.*):\d+$", node_name)
            if m:
                node_name = m.group(1)
            GraphRewriterHelper.node_name_cache[key] = node_name
            return node_name

        return GraphRewriterHelper.node_name_cache[node_name]

    @staticmethod
    def values_from_const(node_def):
        assert node_def.op == 'Const', "Node named '%s' should be a Const op." % node_def.name

        input_tensor = node_def.attr["value"].tensor
        tensor_value = tensor_util.MakeNdarray(input_tensor)
        return tensor_value

def replace_single_node(node_name_details, new_node, old_output_node_names, old_output_name,old_input_node_names, old_input_name):
        new_node_name = new_node.name
        node_details = namedtuple('node_details', ['node', 'outputs'])
        for i in old_output_node_names:
            while old_output_name in node_name_details[i].outputs:
                node_name_details[i].outputs.remove(old_output_name)
            node_name_details[i].outputs.append(new_node_name)

        node_name_details[new_node_name] = node_details(node=new_node,outputs=old_input_node_names)

        for each_input_node_name in old_input_node_names:
            for index, each_node_name in enumerate(
                    node_name_details[each_input_node_name].node.input):
                if node_name_details[each_input_node_name].node.input and (
                        each_node_name) == old_input_name:
                    new_input_name = node_name_details[
                        each_input_node_name].node.input[:index] + [
                            new_node_name
                    ] + node_name_details[each_input_node_name].node.input[index + 1:]
                    node_name_details[each_input_node_name].node.ClearField('input')
                    node_name_details[each_input_node_name].node.input.extend(new_input_name)

        return node_name_details