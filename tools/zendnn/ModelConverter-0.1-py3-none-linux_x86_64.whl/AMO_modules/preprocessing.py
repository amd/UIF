#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import os
import sys
import argparse
import tensorflow as tf
from collections import namedtuple


def get_output_path(model_file, out_location):
    if os.path.isfile(model_file):
        model_bname = os.path.basename(model_file)
        amd_opt_pb = os.path.splitext(model_bname)[0] + '_amd_opt.pb'
        if os.path.isdir(out_location):
            amd_opt_pb = os.path.join(out_location, amd_opt_pb)
        else:
            print ("ERROR: Output location not found!")
            sys.exit(1)
        print ("AMD optimized pb file: %s" %(amd_opt_pb))
        return(amd_opt_pb)

def get_graph_details(model_file):
    # Read infile graph format
    graph_def = tf.compat.v1.GraphDef()
    with tf.compat.v2.io.gfile.GFile(model_file, 'rb') as f:
        graph_def.ParseFromString(f.read())

    node_details = namedtuple('node_details', ['node', 'outputs', 'parent', 'siblings','children'])

    node_name_details = {}

    # Convert inmemory graph format
    for current_node in graph_def.node:
        current_node_name = current_node.name
        current_node_details = node_details(node=current_node, outputs=[], parent=[], siblings=[], children=[])
        if current_node_name not in node_name_details:
            node_name_details[current_node_name] = current_node_details

    for node_name, node_details in node_name_details.items():
        for current_input in node_details.node.input:
            if current_input in node_name_details:
                if node_name_details[current_input].node.op != "Const":
                    node_name_details[node_name].parent.append(current_input)
                    node_name_details[current_input].children.append(node_name)
                node_name_details[current_input].outputs.append(node_name)
            else:
                print(["not found",current_input])

    return(node_name_details)