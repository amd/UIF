#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2, types_pb2
from AMO_modules.helper_routines import query_fusion_pattern_nodes
from AMO_modules.helper_functions import get_number_of_neurons, print_number_of_FNs,  modify_parent_child, function_find_child_FN, isrelu_of_first_preceding_conv
from AMO_modules.helper_functions import set_tout_to_first_parental_avgpool, find_first_non_fc_node_in_parental_chain, set_t_to_all_children_nodes, find_first_conv_node_in_parental_chain


def remove_FNs_with_aquant(node_name_details):
    # Remove all FNs
    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        parents = node_name_details[current_node].parent
        children = node_name_details[current_node].children

        # Leaving bias/wquant in the tail end
        if current_node.endswith('aquant'):
            if len(parents) == 1:
                for child in children:
                    length = len(node_name_details[child].node.input)
                    for idx in range(0, length):
                        if node_name_details[child].node.input[idx] == current_node :
                            node_name_details[child].node.input[idx] = parents[0]

                node_name_details.pop(current_node)
                ''' calling modify_parent_child() so that, after each iteration, parent list of the
                nodes get updated along with the input list. This will eliminate key error in case
                one FixNeuron is given as input to another FixNeuron '''
                modify_parent_child(node_name_details)

    return(node_name_details)

def remove_all_FNs(node_name_details):
    target_pattern = query_fusion_pattern_nodes(node_name_details, ['FixNeuron'])
    for current_pattern in target_pattern:
        if current_pattern:
            node_name_details.pop(current_pattern[0])
    return(node_name_details)