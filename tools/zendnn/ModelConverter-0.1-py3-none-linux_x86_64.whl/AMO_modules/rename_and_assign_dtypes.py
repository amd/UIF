#*******************************************************************************
# Copyright (c) 2022 Advanced Micro Devices, Inc. All rights reserved.
#*******************************************************************************

import tensorflow as tf
import copy
from tensorflow.core.framework import attr_value_pb2, types_pb2
from AMO_modules.helper_routines import query_fusion_pattern_nodes
from AMO_modules.helper_functions import isrelu_of_first_preceding_conv, modify_parent_child
from AMO_modules.helper_functions import set_tout_to_first_parental_avgpool, find_first_non_fc_node_in_parental_chain, set_t_to_all_children_nodes, find_first_conv_node_in_parental_chain
from AMO_modules.remove_fix_neurons import remove_FNs_with_aquant, remove_all_FNs


def rename_assign_dtypes(node_name_details, mul_nodes_to_be_retained, mul_nodes_to_be_eliminated):

    graph_details = copy.copy(node_name_details)

    for current_node in graph_details:
        # Checks both Conv2D and DepthwiseConv2dNative'
        if node_name_details[current_node].node.op == 'Conv2D' or node_name_details[current_node].node.op == 'DepthwiseConv2dNative' :

            # Assigning Toutput attribute
            if node_name_details[current_node].node.attr['is_relu'].b:
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
            else:
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

            ''' Checking if the conv node has atleast one parent, before entering into a recursive search of
            'isrelu_of_first_preceeding_conv' '''
            if len(node_name_details[current_node].parent) == 1:
                if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details) == -1:
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
                elif isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details):
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
                else:
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

            # If there exists two parents to the conv node, 'is_sum' is true.
            # Adding Tsum attribute to those conv nodes, in addition to Tinput
            elif node_name_details[current_node].node.attr['is_sum'].b:
                if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details) == -1:
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
                elif isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details):
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
                else:
                    node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

                if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[1], node_name_details) == -1:
                    node_name_details[current_node].node.attr["Tsum"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
                elif isrelu_of_first_preceding_conv(node_name_details[current_node].parent[1], node_name_details):
                    node_name_details[current_node].node.attr["Tsum"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
                else:
                    node_name_details[current_node].node.attr["Tsum"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

            #  If there is conv node with no valid parent, then the conv node is invalid
            else:
                print("Possible invalid convolution node detected")

    # Maxpool and Average pool transformation
    for current_node in graph_details:
        # Set Tin=Tout of all maxpool and average pool nodes based on 'is_relu'
        if node_name_details[current_node].node.op =='MaxPool' or node_name_details[current_node].node.op =='AvgPool':
            if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details):
                node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
            else:
                node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

            if node_name_details[current_node].node.op == 'MaxPool':
                node_name_details[current_node].node.op = "VitisAIMaxPool"
            else:
                node_name_details[current_node].node.op = "VitisAIAvgPool"


    # Pad node transformation
    for current_node in graph_details:
        if node_name_details[current_node].node.op =='Pad':
            if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details) == -1 :
                node_name_details[current_node].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            elif isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details):
                node_name_details[current_node].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
            else:
                node_name_details[current_node].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

    # Tail end transformations

    # Handling attribute issue caused due to the presence of 'Mean' layer by converting them into 'Average pool' layer
    for current_node in graph_details:
        if node_name_details[current_node].node.op =='Mean':
            parent = node_name_details[current_node].parent[0]
            # Extracting the dimensions of the parent conv node so as to determine the kernel dimensions of average pool layer
            dim_1 = node_name_details[parent].node.attr["_output_shapes"].list.shape[0].dim[1].size
            dim_2 = node_name_details[parent].node.attr["_output_shapes"].list.shape[0].dim[2].size

            node_name_details[current_node].node.op = "VitisAIAvgPool"

            if isrelu_of_first_preceding_conv(node_name_details[current_node].parent[0], node_name_details):
                node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))
            else:
                node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))
                node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QINT8))

            ksize_list_value = attr_value_pb2.AttrValue.ListValue(i=[1,dim_1,dim_2,1])
            node_name_details[current_node].node.attr['ksize'].CopyFrom(attr_value_pb2.AttrValue(list=ksize_list_value))

            strides_list_value = attr_value_pb2.AttrValue.ListValue(i=[1,1,1,1])
            node_name_details[current_node].node.attr['strides'].CopyFrom(attr_value_pb2.AttrValue(list=strides_list_value))

            node_name_details[current_node].node.attr['data_format'].CopyFrom(attr_value_pb2.AttrValue(s=str.encode("NHWC")))
            node_name_details[current_node].node.attr['padding'].CopyFrom(attr_value_pb2.AttrValue(s=str.encode("VALID")))

            # Popping out the unnecessary attributes of the 'Mean' node and changing according to Average pool's attributes
            node_name_details[current_node].node.attr.pop('keep_dims')
            node_name_details[current_node].node.attr.pop('Tidx')
            node_name_details[current_node].node.attr.pop('T')
            # Popping out 'reduction_indices' from the node's input as average pool does not have this input
            # Also popping it out from the node_name_details so as to avoid dangling const nodes in output
            node_name_details.pop(node_name_details[current_node].node.input.pop(1))

    # Enters this block only if atleast one mul node needs to be retained
    for mul_node in mul_nodes_to_be_retained:
        parents =  node_name_details[mul_node].parent
        children =  node_name_details[mul_node].children

        if len(parents) == 1:
            parent = parents[0]
            child =  children[0]

            if node_name_details[parent].node.op == "VitisAIAvgPool":
                # For the Avgpool node that is preceding Mul, set Tout to float
                node_name_details[parent].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            if('Conv' in node_name_details[child].node.op):
                # For conv node that is succeeding Mul, set Tin to float
                node_name_details[child].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))

    # Enters this block when all mul nodes are to be eliminated
    for mul_node in mul_nodes_to_be_eliminated:
        parents = node_name_details[mul_node].parent
        children = node_name_details[mul_node].children

        if len(parents) == 1:
            for child in children:
                length = len(node_name_details[child].node.input)
                for idx in range(0, length):
                    if node_name_details[child].node.input[idx] == mul_node :
                        node_name_details[child].node.input[idx] = parents[0]
            node_name_details.pop(node_name_details[mul_node].node.input.pop(1))
            node_name_details.pop(mul_node)

    # Since some nodes are getting removed, we need to update graph_details and parent-child list
    modify_parent_child(node_name_details)
    graph_details = copy.copy(node_name_details)

    # Remove T and add Tweight, Tbias
    for current_node in graph_details:
        if 'Conv' in current_node or 'depthwise' in current_node:
            node_name_details[current_node].node.attr.pop('T')
            node_name_details[current_node].node.attr["Tfilter"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            node_name_details[current_node].node.attr["Tbias"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
        if node_name_details[current_node].node.op == "VitisAIAvgPool" or node_name_details[current_node].node.op == "VitisAIMaxPool":
            node_name_details[current_node].node.attr.pop('T')

    # Rename DepthwiseConv2dNative nodes
    for current_node in graph_details:
        if node_name_details[current_node].node.op =='DepthwiseConv2dNative':
            node_name_details[current_node].node.op = "VitisAIDepthwiseConv2D"

    # Rename nodes based on is_sum
    target_nodes = query_fusion_pattern_nodes(node_name_details, ['Conv2D'])
    for node in target_nodes:
        if node_name_details[node[0]].node.attr['is_sum'].b:
            node_name_details[node[0]].node.op = "VitisAIConv2DWithSum"
        elif node_name_details[node[0]].node.attr.get('bias_scale') is None:
            node_name_details[node[0]].node.op = "VitisAIConv2DWithoutBias"
            node_name_details[node[0]].node.attr.pop('Tbias')
        else:
            node_name_details[node[0]].node.op = "VitisAIConv2D"

    # Concat transformation
    ''' It is assumed that all the input nodes to concat have the same output type and
    there are no mixed input attributes '''

    target_nodes = query_fusion_pattern_nodes(node_name_details, ['ConcatV2'])

    ''' As VitisAIConcatV2 supports only quint8 attribute, we transform the ConcatV2 node
    into VitisAIConcatV2 only if all the parent nodes to concat give quint8 output. But if all
    parent nodes give float output, the ConcatV2 nodes are not transformed to VitisAIConcatV2.
    Optimized model is generated in both the above cases'''
    for node in target_nodes:
        get_dtype_of_first_parent = 0
        parents_with_uint_tout = 0
        # Check the output attribute of parent nodes of concat
        for parent in node_name_details[node[0]].parent:
            if("Toutput" in node_name_details[parent].node.attr):
                dtype = node_name_details[parent].node.attr["Toutput"].type
            else:
                dtype = node_name_details[parent].node.attr["T"].type

            # Fetching the attribute of first parent, to compare it with the other parent attributes
            if(get_dtype_of_first_parent == 0):
                current_dtype = dtype
                get_dtype_of_first_parent = 1

            ''' Check if the attribute of all parents are same and are not qint8.
            If not, exit, as mixed input attributes and qint8 input to concat is not supported'''
            if(dtype != current_dtype or dtype == types_pb2.DT_QINT8):
                print("Mixed input attributes or qint8 input to Concat is not supported")
                exit(0)
            else:
                if(dtype == types_pb2.DT_QUINT8):
                    parents_with_uint_tout = parents_with_uint_tout + 1

        if(parents_with_uint_tout == len(node_name_details[node[0]].parent)):
            node_name_details[node[0]].node.op = "VitisAIConcatV2"
            node_name_details[node[0]].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_QUINT8))

    node_name_details = remove_all_FNs(node_name_details)

    # We need to update graph_details and parent-child list, as some FNs were removed
    modify_parent_child(node_name_details)
    graph_details = copy.copy(node_name_details)

    ''' Toutput or T attribute of the node that's preceding Squeeze, Shape nodes should be float.
    If Reshape has only one parent (without shape node), it's parent's Tout or T is changed to float'''
    for current_node in graph_details:
        if(node_name_details[current_node].node.op == 'Shape' or node_name_details[current_node].node.op == 'Squeeze' or
        node_name_details[current_node].node.op == 'Reshape' and len(node_name_details[current_node].parent) == 1):
            parent = node_name_details[current_node].parent[0]
            if(node_name_details[parent].node.op != "VitisAIConv2DWithSum"):
                if("Toutput" in node_name_details[parent].node.attr):
                    node_name_details[parent].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
                else:
                    node_name_details[parent].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            else:
                '''  Causes potential error during validation if 'VitisAIConv2dWithSum' has
                int input and float output '''
                print("VitisAIConv2dWithSum does not support int input and float output")
                exit(0)

    for current_node in graph_details:
        if current_node == 'refinedet320/pool5/MaxPool':
            node_name_details[current_node].node.op = 'MaxPool'
        if current_node == 'refinedet320/conv5/conv5_3/Conv2D':
            node_name_details[current_node].node.attr["Toutput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
        if current_node == 'refinedet320/fc6_m/Conv2D':
            node_name_details[current_node].node.op = 'Conv2D'
            node_name_details[current_node].node.attr["T"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))
            node_name_details[current_node].node.attr.pop('Tinput')
            node_name_details[current_node].node.attr.pop('Toutput')
            node_name_details[current_node].node.attr.pop('Tfilter')
            node_name_details[current_node].node.attr.pop('Tbias')
        if current_node == 'refinedet320/fc7_m/Conv2D':
            node_name_details[current_node].node.attr["Tinput"].CopyFrom(attr_value_pb2.AttrValue(type=types_pb2.DT_FLOAT))

    return(node_name_details)

def matmul_biasadd_fixes(output_graph_def):
    # Temp fixes
    for current_node in output_graph_def.node:
        if current_node.name == 'InceptionV4/Logits/Logits/MatMul':
            current_node.input[1] = 'InceptionV4/Logits/Logits/weights'
        elif current_node.name == 'InceptionV4/Logits/Logits/BiasAdd':
            current_node.input[1] = 'InceptionV4/Logits/Logits/biases'

    for current_node in output_graph_def.node:
        if current_node.name == 'refinedet320/fc6_m/BiasAdd':
            current_node.input[1] = 'refinedet320/fc6_m/bias'

    for current_node in output_graph_def.node:
        if current_node.name == 'efficientnet-edgetpu-S/model/head/dense/MatMul':
            current_node.input[1] = 'efficientnet-edgetpu-S/head/dense/kernel'
        elif current_node.name == 'efficientnet-edgetpu-S/model/head/dense/BiasAdd':
            current_node.input[1] = 'efficientnet-edgetpu-S/head/dense/bias'

    for current_node in output_graph_def.node:
        if current_node.name == 'efficientnet-edgetpu-M/model/head/dense/MatMul':
            current_node.input[1] = 'efficientnet-edgetpu-M/head/dense/kernel'
        elif current_node.name == 'efficientnet-edgetpu-M/model/head/dense/BiasAdd':
            current_node.input[1] = 'efficientnet-edgetpu-M/head/dense/bias'

    for current_node in output_graph_def.node:
        if current_node.name == 'efficientnet-edgetpu-L/model/head/dense/MatMul':
            current_node.input[1] = 'efficientnet-edgetpu-L/head/dense/kernel'
        elif current_node.name == 'efficientnet-edgetpu-L/model/head/dense/BiasAdd':
            current_node.input[1] = 'efficientnet-edgetpu-L/head/dense/bias'

    return(output_graph_def)